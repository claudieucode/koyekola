import React from "react";
import { ActivityIndicator, View } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";

import { useAuth } from "../context/AuthContext";
import LoginScreen from "../screens/LoginScreen";
import DashboardScreen from "../screens/DashboardScreen";
import CampaignsScreen from "../screens/CampaignsScreen";
import CampaignDetailScreen from "../screens/CampaignDetailScreen";
import ContactsScreen from "../screens/ContactsScreen";
import ContactDetailScreen from "../screens/ContactDetailScreen";

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const COLORS = { primary: "#1E3A5F", accent: "#E8B84B", bg: "#F5F7FA" };

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerStyle: { backgroundColor: COLORS.primary },
        headerTintColor: "#fff",
        headerTitleStyle: { fontWeight: "bold" },
        tabBarActiveTintColor: COLORS.accent,
        tabBarInactiveTintColor: "#888",
        tabBarStyle: { backgroundColor: "#fff", borderTopColor: "#e0e0e0" },
        tabBarIcon: ({ focused, color, size }) => {
          const icons = {
            Dashboard: focused ? "grid" : "grid-outline",
            Campaigns: focused ? "mail" : "mail-outline",
            Contacts: focused ? "people" : "people-outline",
          };
          return <Ionicons name={icons[route.name] || "ellipse"} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen} options={{ title: "Tableau de bord" }} />
      <Tab.Screen name="Campaigns" component={CampaignsScreen} options={{ title: "Campagnes" }} />
      <Tab.Screen name="Contacts" component={ContactsScreen} options={{ title: "Contacts" }} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: COLORS.primary }}>
        <ActivityIndicator size="large" color={COLORS.accent} />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {user ? (
          <>
            <Stack.Screen name="Main" component={MainTabs} />
            <Stack.Screen
              name="CampaignDetail"
              component={CampaignDetailScreen}
              options={{
                headerShown: true,
                title: "Campagne",
                headerStyle: { backgroundColor: COLORS.primary },
                headerTintColor: "#fff",
              }}
            />
            <Stack.Screen
              name="ContactDetail"
              component={ContactDetailScreen}
              options={{
                headerShown: true,
                title: "Contact",
                headerStyle: { backgroundColor: COLORS.primary },
                headerTintColor: "#fff",
              }}
            />
          </>
        ) : (
          <Stack.Screen name="Login" component={LoginScreen} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
