import React, { useState, useCallback } from "react";
import {
  View, Text, ScrollView, StyleSheet, RefreshControl,
  TouchableOpacity, Alert, ActivityIndicator,
} from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import { getOverview } from "../api/client";
import { useAuth } from "../context/AuthContext";

const C = { primary: "#1E3A5F", accent: "#E8B84B", bg: "#F5F7FA", text: "#222", muted: "#666" };

const fmt = (n) => (n == null ? "—" : Number(n).toLocaleString("fr-FR"));
const pct = (n) => (n == null ? "—" : `${Number(n).toFixed(1)} %`);

function StatCard({ icon, label, value, sub, color }) {
  return (
    <View style={[styles.statCard, color && { borderLeftColor: color, borderLeftWidth: 4 }]}>
      <Ionicons name={icon} size={22} color={color || C.primary} style={{ marginBottom: 6 }} />
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
      {sub ? <Text style={styles.statSub}>{sub}</Text> : null}
    </View>
  );
}

function AlertBanner({ alerts }) {
  if (!alerts?.length) return null;
  return (
    <View style={styles.alertBox}>
      {alerts.map((a, i) => (
        <View key={i} style={styles.alertRow}>
          <Ionicons
            name={a.level === "error" ? "alert-circle" : "warning"}
            size={16}
            color={a.level === "error" ? "#D32F2F" : "#F57C00"}
          />
          <Text style={styles.alertText}>{a.message}</Text>
        </View>
      ))}
    </View>
  );
}

export default function DashboardScreen({ navigation }) {
  const { user, logout } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const load = useCallback(async (isRefresh = false) => {
    if (!isRefresh) setLoading(true);
    setError(null);
    try {
      const res = await getOverview();
      setData(res.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const onRefresh = () => { setRefreshing(true); load(true); };

  const handleLogout = () =>
    Alert.alert("Déconnexion", "Voulez-vous vous déconnecter ?", [
      { text: "Annuler", style: "cancel" },
      { text: "Déconnecter", style: "destructive", onPress: logout },
    ]);

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Tableau de bord</Text>
          <Text style={styles.headerSub}>Bonjour, {user?.username || "formateur"}</Text>
        </View>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
          <Ionicons name="log-out-outline" size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Contenu */}
      {loading && !data ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={C.primary} />
        </View>
      ) : error ? (
        <View style={styles.center}>
          <Ionicons name="cloud-offline-outline" size={48} color="#ccc" />
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryBtn} onPress={() => load()}>
            <Text style={styles.retryText}>Réessayer</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={styles.scroll}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={C.primary} />}
        >
          {/* Alertes */}
          <AlertBanner alerts={data?.alerts} />

          {/* Période */}
          {data?.period && (
            <Text style={styles.period}>
              Période : {data.period.label || "30 derniers jours"}
            </Text>
          )}

          {/* Contacts */}
          <Text style={styles.sectionTitle}>Contacts</Text>
          <View style={styles.row}>
            <StatCard icon="people" label="Total" value={fmt(data?.contacts?.total)} color={C.primary} />
            <StatCard icon="checkmark-circle" label="Actifs" value={fmt(data?.contacts?.byStatus?.subscribed ?? data?.contacts?.sendable)} color="#388E3C" />
          </View>
          <View style={styles.row}>
            <StatCard icon="person-add" label="Nouveaux" value={fmt(data?.contacts?.newInPeriod)} color="#1976D2" />
            <StatCard icon="remove-circle" label="Désabonnés" value={fmt(data?.contacts?.unsubscribedInPeriod)} color="#F57C00" />
          </View>

          {/* Campagnes */}
          <Text style={styles.sectionTitle}>Campagnes (période)</Text>
          <View style={styles.row}>
            <StatCard icon="mail" label="Envoyées" value={fmt(data?.campaigns?.sentInPeriod)} color={C.primary} />
            <StatCard icon="paper-plane" label="Messages" value={fmt(data?.campaigns?.messagesInPeriod)} color="#7B1FA2" />
          </View>
          <View style={styles.row}>
            <StatCard icon="mouse" label="Taux de clic" value={pct(data?.campaigns?.clickRate)} color="#1976D2" />
            <StatCard icon="return-down-back" label="Taux bounce" value={pct(data?.campaigns?.bounceRate)} color="#D32F2F" />
          </View>

          {/* Automatisations */}
          <Text style={styles.sectionTitle}>Automatisations</Text>
          <View style={styles.row}>
            <StatCard icon="flash" label="Actives" value={fmt(data?.automations?.active)} color="#388E3C" />
            <StatCard icon="pause-circle" label="En pause" value={fmt(data?.automations?.paused)} color="#F57C00" />
          </View>

          {/* Activité récente */}
          {data?.activity?.length > 0 && (
            <>
              <Text style={styles.sectionTitle}>Activité récente</Text>
              {data.activity.map((a, i) => (
                <View key={i} style={styles.activityRow}>
                  <Ionicons name="time-outline" size={14} color={C.muted} style={{ marginRight: 8 }} />
                  <Text style={styles.activityText}>{a.label || a.type || JSON.stringify(a)}</Text>
                </View>
              ))}
            </>
          )}

          <View style={{ height: 24 }} />
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: {
    backgroundColor: C.primary, paddingTop: 50, paddingBottom: 18,
    paddingHorizontal: 20, flexDirection: "row", justifyContent: "space-between", alignItems: "center",
  },
  headerTitle: { color: "#fff", fontSize: 22, fontWeight: "bold" },
  headerSub: { color: "rgba(255,255,255,0.7)", fontSize: 13, marginTop: 2 },
  logoutBtn: { padding: 4 },
  scroll: { padding: 16 },
  center: { flex: 1, justifyContent: "center", alignItems: "center", padding: 24 },
  period: { color: C.muted, fontSize: 12, marginBottom: 12 },
  sectionTitle: { fontSize: 16, fontWeight: "bold", color: C.primary, marginTop: 20, marginBottom: 10 },
  row: { flexDirection: "row", gap: 12, marginBottom: 4 },
  statCard: {
    flex: 1, backgroundColor: "#fff", borderRadius: 12, padding: 14,
    elevation: 2, shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 4, shadowOffset: { height: 2 },
    marginBottom: 12,
  },
  statValue: { fontSize: 24, fontWeight: "bold", color: C.text },
  statLabel: { fontSize: 12, color: C.muted, marginTop: 2 },
  statSub: { fontSize: 11, color: C.muted, marginTop: 1 },
  alertBox: { backgroundColor: "#FFF8E1", borderRadius: 10, padding: 12, marginBottom: 12 },
  alertRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 4 },
  alertText: { fontSize: 13, color: "#333", flex: 1 },
  errorText: { color: C.muted, marginTop: 12, textAlign: "center", fontSize: 14 },
  retryBtn: { marginTop: 16, backgroundColor: C.primary, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 8 },
  retryText: { color: "#fff", fontWeight: "bold" },
  activityRow: { flexDirection: "row", alignItems: "center", paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: "#eee" },
  activityText: { fontSize: 13, color: C.text, flex: 1 },
});
