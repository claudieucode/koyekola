import React, { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ActivityIndicator, Alert, ScrollView,
} from "react-native";
import { useAuth } from "../context/AuthContext";

const C = { primary: "#1E3A5F", accent: "#E8B84B", error: "#D32F2F", bg: "#F5F7FA", text: "#222" };

export default function LoginScreen() {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password) {
      Alert.alert("Champs requis", "Veuillez entrer votre email et mot de passe.");
      return;
    }
    setLoading(true);
    try {
      await login(email.trim().toLowerCase(), password);
      // la navigation est gérée automatiquement par AppNavigator
    } catch (err) {
      const msg =
        err.status === 401 ? "Email ou mot de passe incorrect." :
        err.status === 403 ? "Accès réservé aux administrateurs (formateurs)." :
        err.status === 503 ? "Le module marketing est indisponible sur le serveur." :
        err.message || "Erreur de connexion. Vérifiez votre connexion réseau.";
      Alert.alert("Connexion échouée", msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        {/* Logo / titre */}
        <View style={styles.header}>
          <Text style={styles.logo}>K</Text>
          <Text style={styles.appName}>Koyekola</Text>
          <Text style={styles.subtitle}>Tableau de bord marketing</Text>
        </View>

        {/* Formulaire */}
        <View style={styles.card}>
          <Text style={styles.label}>Email</Text>
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            placeholder="votre@email.com"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="next"
          />

          <Text style={styles.label}>Mot de passe</Text>
          <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            placeholder="••••••••"
            secureTextEntry
            returnKeyType="go"
            onSubmitEditing={handleLogin}
          />

          <TouchableOpacity
            style={[styles.button, loading && styles.buttonDisabled]}
            onPress={handleLogin}
            disabled={loading}
          >
            {loading
              ? <ActivityIndicator color="#fff" />
              : <Text style={styles.buttonText}>Se connecter</Text>
            }
          </TouchableOpacity>
        </View>

        <Text style={styles.hint}>Réservé aux formateurs (administrateurs)</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: C.primary },
  container: { flexGrow: 1, justifyContent: "center", padding: 24 },
  header: { alignItems: "center", marginBottom: 36 },
  logo: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: C.accent, textAlign: "center",
    fontSize: 40, lineHeight: 72, fontWeight: "bold", color: C.primary,
    overflow: "hidden",
  },
  appName: { color: "#fff", fontSize: 28, fontWeight: "bold", marginTop: 12 },
  subtitle: { color: "rgba(255,255,255,0.7)", fontSize: 14, marginTop: 4 },
  card: { backgroundColor: "#fff", borderRadius: 16, padding: 24, elevation: 4 },
  label: { fontSize: 13, color: "#666", marginBottom: 6, marginTop: 12 },
  input: {
    borderWidth: 1, borderColor: "#ddd", borderRadius: 8,
    padding: 12, fontSize: 16, color: C.text, backgroundColor: C.bg,
  },
  button: {
    backgroundColor: C.primary, borderRadius: 8, padding: 15,
    alignItems: "center", marginTop: 24,
  },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { color: "#fff", fontSize: 16, fontWeight: "bold" },
  hint: { color: "rgba(255,255,255,0.5)", fontSize: 12, textAlign: "center", marginTop: 20 },
});
