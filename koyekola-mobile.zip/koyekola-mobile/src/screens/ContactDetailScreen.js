import React, { useState, useEffect, useLayoutEffect } from "react";
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  ActivityIndicator, RefreshControl,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { getContact } from "../api/client";

const C = { primary: "#1E3A5F", bg: "#F5F7FA", text: "#222", muted: "#666" };

const STATUS_COLOR = {
  subscribed:   "#388E3C",
  unsubscribed: "#F57C00",
  bounced:      "#D32F2F",
  complained:   "#B71C1C",
  unknown:      "#888",
};

const STATUS_LABEL = {
  subscribed:   "Abonné",
  unsubscribed: "Désabonné",
  bounced:      "Bounce",
  complained:   "Plainte",
  unknown:      "Inconnu",
};

function InfoRow({ icon, label, value }) {
  if (!value && value !== 0) return null;
  return (
    <View style={styles.infoRow}>
      <Ionicons name={icon} size={16} color={C.muted} style={{ width: 24 }} />
      <View style={styles.infoContent}>
        <Text style={styles.infoLabel}>{label}</Text>
        <Text style={styles.infoVal}>{String(value)}</Text>
      </View>
    </View>
  );
}

export default function ContactDetailScreen({ route, navigation }) {
  const { id, email } = route.params;
  const [contact, setContact] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  useLayoutEffect(() => {
    navigation.setOptions({ title: email || "Contact" });
  }, [email]);

  const load = async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true); else setLoading(true);
    setError(null);
    try {
      const res = await getContact(id);
      setContact(res.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { load(); }, [id]);

  if (loading) {
    return <View style={styles.center}><ActivityIndicator size="large" color={C.primary} /></View>;
  }
  if (error) {
    return (
      <View style={styles.center}>
        <Ionicons name="cloud-offline-outline" size={48} color="#ccc" />
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity style={styles.retryBtn} onPress={() => load()}>
          <Text style={styles.retryText}>Réessayer</Text>
        </TouchableOpacity>
      </View>
    );
  }
  if (!contact) return null;

  const status = contact.status || "unknown";
  const statusColor = STATUS_COLOR[status] || "#888";
  const statusLabel = STATUS_LABEL[status] || status;
  const name = [contact.first_name, contact.last_name].filter(Boolean).join(" ");
  const initials = ((contact.first_name?.[0] || "") + (contact.last_name?.[0] || "")).toUpperCase() || contact.email?.[0]?.toUpperCase() || "?";
  const fmtDate = (d) => d ? new Date(d).toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" }) : null;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.scroll}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load(true)} tintColor={C.primary} />}
    >
      {/* Avatar + nom */}
      <View style={styles.profileCard}>
        <View style={[styles.avatar, { backgroundColor: C.primary + "15" }]}>
          <Text style={styles.avatarText}>{initials}</Text>
        </View>
        {name ? <Text style={styles.profileName}>{name}</Text> : null}
        <Text style={styles.profileEmail}>{contact.email}</Text>
        <View style={[styles.statusBadge, { backgroundColor: statusColor + "20" }]}>
          <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
          <Text style={[styles.statusLabel, { color: statusColor }]}>{statusLabel}</Text>
        </View>
      </View>

      {/* Détails */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Informations</Text>
        <InfoRow icon="mail-outline" label="Email" value={contact.email} />
        <InfoRow icon="person-outline" label="Prénom" value={contact.first_name} />
        <InfoRow icon="person-outline" label="Nom" value={contact.last_name} />
        <InfoRow icon="link-outline" label="Source" value={contact.source} />
        <InfoRow icon="calendar-outline" label="Inscrit le" value={fmtDate(contact.created_at)} />
        {contact.unsubscribed_at && (
          <InfoRow icon="exit-outline" label="Désabonné le" value={fmtDate(contact.unsubscribed_at)} />
        )}
      </View>

      {/* Données custom si présentes */}
      {contact.metadata && typeof contact.metadata === "object" && Object.keys(contact.metadata).length > 0 && (
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Données personnalisées</Text>
          {Object.entries(contact.metadata).map(([k, v]) => (
            <InfoRow key={k} icon="code-outline" label={k} value={String(v)} />
          ))}
        </View>
      )}

      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  scroll: { padding: 16 },
  center: { flex: 1, justifyContent: "center", alignItems: "center", padding: 24 },
  profileCard: {
    backgroundColor: "#fff", borderRadius: 16, padding: 24,
    alignItems: "center", marginBottom: 12,
    elevation: 2, shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 4, shadowOffset: { height: 2 },
  },
  avatar: {
    width: 72, height: 72, borderRadius: 36,
    justifyContent: "center", alignItems: "center", marginBottom: 14,
  },
  avatarText: { fontSize: 28, fontWeight: "bold", color: C.primary },
  profileName: { fontSize: 20, fontWeight: "bold", color: C.text, marginBottom: 4 },
  profileEmail: { fontSize: 14, color: C.muted, marginBottom: 12 },
  statusBadge: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 12, paddingVertical: 5, borderRadius: 14 },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  statusLabel: { fontSize: 13, fontWeight: "700" },
  card: {
    backgroundColor: "#fff", borderRadius: 14, padding: 16, marginBottom: 12,
    elevation: 2, shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 4, shadowOffset: { height: 2 },
  },
  sectionTitle: { fontSize: 14, fontWeight: "700", color: C.primary, marginBottom: 12 },
  infoRow: { flexDirection: "row", alignItems: "flex-start", paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: "#f5f5f5" },
  infoContent: { flex: 1, marginLeft: 4 },
  infoLabel: { fontSize: 11, color: C.muted, marginBottom: 2 },
  infoVal: { fontSize: 14, color: C.text },
  errorText: { color: C.muted, marginTop: 12, textAlign: "center" },
  retryBtn: { marginTop: 16, backgroundColor: C.primary, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 8 },
  retryText: { color: "#fff", fontWeight: "bold" },
});
