import React, { useState, useCallback } from "react";
import {
  View, Text, FlatList, StyleSheet, TouchableOpacity,
  TextInput, RefreshControl, ActivityIndicator,
} from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import { getCampaigns } from "../api/client";

const C = { primary: "#1E3A5F", accent: "#E8B84B", bg: "#F5F7FA", text: "#222", muted: "#888" };

const STATUS_CONFIG = {
  draft:      { label: "Brouillon",   color: "#888",    icon: "document-outline" },
  scheduled:  { label: "Planifiée",   color: "#1976D2", icon: "calendar-outline" },
  sending:    { label: "En cours",    color: "#388E3C", icon: "paper-plane-outline" },
  sent:       { label: "Envoyée",     color: "#2E7D32", icon: "checkmark-circle" },
  paused:     { label: "En pause",    color: "#F57C00", icon: "pause-circle-outline" },
  cancelled:  { label: "Annulée",     color: "#D32F2F", icon: "close-circle-outline" },
  failed:     { label: "Échec",       color: "#B71C1C", icon: "alert-circle-outline" },
};

const STATUS_FILTERS = [
  { key: "", label: "Toutes" },
  { key: "sending", label: "En cours" },
  { key: "scheduled", label: "Planifiées" },
  { key: "sent", label: "Envoyées" },
  { key: "draft", label: "Brouillons" },
  { key: "paused", label: "En pause" },
];

function StatusBadge({ status }) {
  const cfg = STATUS_CONFIG[status] || { label: status, color: C.muted, icon: "ellipse" };
  return (
    <View style={[styles.badge, { backgroundColor: cfg.color + "20" }]}>
      <Ionicons name={cfg.icon} size={12} color={cfg.color} />
      <Text style={[styles.badgeText, { color: cfg.color }]}>{cfg.label}</Text>
    </View>
  );
}

function CampaignItem({ item, onPress }) {
  const date = item.scheduled_at || item.finished_at || item.created_at;
  const dateStr = date ? new Date(date).toLocaleDateString("fr-FR", { day: "2-digit", month: "short", year: "numeric" }) : null;

  return (
    <TouchableOpacity style={styles.card} onPress={() => onPress(item)}>
      <View style={styles.cardTop}>
        <Text style={styles.cardName} numberOfLines={2}>{item.name}</Text>
        <StatusBadge status={item.status} />
      </View>
      <View style={styles.cardMeta}>
        <Ionicons name="mail-outline" size={13} color={C.muted} />
        <Text style={styles.cardMetaText}>
          {item.sent_count != null ? `${Number(item.sent_count).toLocaleString("fr-FR")} envois` : "—"}
        </Text>
        {dateStr && (
          <>
            <Text style={styles.dot}>·</Text>
            <Ionicons name="calendar-outline" size={13} color={C.muted} />
            <Text style={styles.cardMetaText}>{dateStr}</Text>
          </>
        )}
      </View>
    </TouchableOpacity>
  );
}

export default function CampaignsScreen({ navigation }) {
  const [campaigns, setCampaigns] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState("");
  const [activeStatus, setActiveStatus] = useState("");
  const [error, setError] = useState(null);

  const load = useCallback(async ({ status = activeStatus, q = search, pg = 1, refresh = false } = {}) => {
    if (pg === 1) { if (refresh) setRefreshing(true); else setLoading(true); }
    else setLoadingMore(true);
    setError(null);
    try {
      const res = await getCampaigns({ status: status || undefined, q: q || undefined, page: pg });
      if (pg === 1) setCampaigns(res.data);
      else setCampaigns((prev) => [...prev, ...res.data]);
      setTotal(res.total || 0);
      setHasMore(res.hasMore || false);
      setPage(pg);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
      setLoadingMore(false);
    }
  }, [activeStatus, search]);

  useFocusEffect(useCallback(() => { load({ pg: 1 }); }, [activeStatus]));

  const handleSearch = (text) => {
    setSearch(text);
    if (text.length === 0 || text.length >= 2) load({ q: text, pg: 1 });
  };

  const handleFilter = (key) => { setActiveStatus(key); };

  const loadMore = () => {
    if (hasMore && !loadingMore) load({ pg: page + 1 });
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Campagnes</Text>
        <Text style={styles.headerSub}>{total} campagne{total !== 1 ? "s" : ""}</Text>
      </View>

      {/* Barre de recherche */}
      <View style={styles.searchBar}>
        <Ionicons name="search-outline" size={18} color={C.muted} style={{ marginRight: 8 }} />
        <TextInput
          style={styles.searchInput}
          placeholder="Rechercher..."
          value={search}
          onChangeText={handleSearch}
          returnKeyType="search"
          clearButtonMode="while-editing"
        />
      </View>

      {/* Filtres par statut */}
      <FlatList
        horizontal
        data={STATUS_FILTERS}
        keyExtractor={(f) => f.key}
        contentContainerStyle={styles.filters}
        showsHorizontalScrollIndicator={false}
        renderItem={({ item: f }) => (
          <TouchableOpacity
            style={[styles.filterChip, activeStatus === f.key && styles.filterChipActive]}
            onPress={() => handleFilter(f.key)}
          >
            <Text style={[styles.filterText, activeStatus === f.key && styles.filterTextActive]}>{f.label}</Text>
          </TouchableOpacity>
        )}
      />

      {/* Liste */}
      {loading && campaigns.length === 0 ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={C.primary} />
        </View>
      ) : error ? (
        <View style={styles.center}>
          <Ionicons name="cloud-offline-outline" size={48} color="#ccc" />
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryBtn} onPress={() => load({ pg: 1 })}>
            <Text style={styles.retryText}>Réessayer</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={campaigns}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load({ pg: 1, refresh: true })} tintColor={C.primary} />}
          onEndReached={loadMore}
          onEndReachedThreshold={0.3}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="mail-open-outline" size={48} color="#ccc" />
              <Text style={styles.emptyText}>Aucune campagne</Text>
            </View>
          }
          ListFooterComponent={loadingMore ? <ActivityIndicator color={C.primary} style={{ margin: 16 }} /> : null}
          renderItem={({ item }) => (
            <CampaignItem item={item} onPress={(c) => navigation.navigate("CampaignDetail", { id: c.id, name: c.name })} />
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { backgroundColor: C.primary, paddingTop: 50, paddingBottom: 16, paddingHorizontal: 20 },
  headerTitle: { color: "#fff", fontSize: 22, fontWeight: "bold" },
  headerSub: { color: "rgba(255,255,255,0.7)", fontSize: 13 },
  searchBar: {
    flexDirection: "row", alignItems: "center", backgroundColor: "#fff",
    margin: 12, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8,
    elevation: 1,
  },
  searchInput: { flex: 1, fontSize: 15, color: C.text },
  filters: { paddingHorizontal: 12, paddingBottom: 8, gap: 8 },
  filterChip: {
    paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20,
    backgroundColor: "#fff", borderWidth: 1, borderColor: "#ddd",
  },
  filterChipActive: { backgroundColor: C.primary, borderColor: C.primary },
  filterText: { fontSize: 13, color: C.text },
  filterTextActive: { color: "#fff", fontWeight: "600" },
  list: { padding: 12, paddingTop: 4 },
  card: {
    backgroundColor: "#fff", borderRadius: 12, padding: 16, marginBottom: 10,
    elevation: 2, shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 4, shadowOffset: { height: 2 },
  },
  cardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 },
  cardName: { fontSize: 15, fontWeight: "600", color: C.text, flex: 1, marginRight: 8 },
  badge: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 12 },
  badgeText: { fontSize: 11, fontWeight: "600" },
  cardMeta: { flexDirection: "row", alignItems: "center", gap: 4 },
  cardMetaText: { fontSize: 12, color: C.muted },
  dot: { color: C.muted, marginHorizontal: 2 },
  center: { flex: 1, justifyContent: "center", alignItems: "center", padding: 24 },
  empty: { alignItems: "center", marginTop: 60 },
  emptyText: { color: C.muted, marginTop: 12, fontSize: 15 },
  errorText: { color: C.muted, marginTop: 12, textAlign: "center" },
  retryBtn: { marginTop: 16, backgroundColor: C.primary, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 8 },
  retryText: { color: "#fff", fontWeight: "bold" },
});
