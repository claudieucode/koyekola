import React, { useState, useCallback } from "react";
import {
  View, Text, FlatList, StyleSheet, TouchableOpacity,
  TextInput, RefreshControl, ActivityIndicator,
} from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import { getContacts } from "../api/client";

const C = { primary: "#1E3A5F", accent: "#E8B84B", bg: "#F5F7FA", text: "#222", muted: "#888" };

const STATUS_COLOR = {
  subscribed:   "#388E3C",
  unsubscribed: "#F57C00",
  bounced:      "#D32F2F",
  complained:   "#B71C1C",
  unknown:      "#888",
};

const STATUS_LABEL = {
  subscribed:   "Abonné",
  unsubscribed: "Désabonné",
  bounced:      "Bounce",
  complained:   "Plainte",
  unknown:      "Inconnu",
};

function ContactItem({ item, onPress }) {
  const initials = ((item.first_name?.[0] || "") + (item.last_name?.[0] || "")).toUpperCase() || item.email?.[0]?.toUpperCase() || "?";
  const color = STATUS_COLOR[item.status] || "#888";
  const label = STATUS_LABEL[item.status] || item.status || "—";
  const name = [item.first_name, item.last_name].filter(Boolean).join(" ") || null;

  return (
    <TouchableOpacity style={styles.card} onPress={() => onPress(item)}>
      <View style={[styles.avatar, { backgroundColor: C.primary + "20" }]}>
        <Text style={styles.avatarText}>{initials}</Text>
      </View>
      <View style={styles.info}>
        {name && <Text style={styles.name}>{name}</Text>}
        <Text style={styles.email} numberOfLines={1}>{item.email}</Text>
        <View style={styles.statusRow}>
          <View style={[styles.dot, { backgroundColor: color }]} />
          <Text style={[styles.statusText, { color }]}>{label}</Text>
          {item.source && <Text style={styles.source}>· {item.source}</Text>}
        </View>
      </View>
      <Ionicons name="chevron-forward" size={16} color="#ccc" />
    </TouchableOpacity>
  );
}

export default function ContactsScreen({ navigation }) {
  const [contacts, setContacts] = useState([]);
  const [nextCursor, setNextCursor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [filtered, setFiltered] = useState([]);

  const load = useCallback(async ({ after = null, refresh = false } = {}) => {
    if (!after) { if (refresh) setRefreshing(true); else setLoading(true); }
    else setLoadingMore(true);
    setError(null);
    try {
      const res = await getContacts({ after: after || undefined, limit: 50 });
      const rows = res.data || [];
      const next = res.next_cursor || null;
      if (!after) { setContacts(rows); setFiltered(rows); }
      else { setContacts((p) => { const all = [...p, ...rows]; setFiltered(filterRows(all, search)); return all; }); }
      setNextCursor(next);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
      setLoadingMore(false);
    }
  }, [search]);

  useFocusEffect(useCallback(() => { load(); }, []));

  const filterRows = (rows, q) => {
    if (!q) return rows;
    const lq = q.toLowerCase();
    return rows.filter((c) =>
      c.email?.toLowerCase().includes(lq) ||
      c.first_name?.toLowerCase().includes(lq) ||
      c.last_name?.toLowerCase().includes(lq)
    );
  };

  const handleSearch = (text) => {
    setSearch(text);
    setFiltered(filterRows(contacts, text));
  };

  const loadMore = () => {
    if (nextCursor && !loadingMore) load({ after: nextCursor });
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Contacts</Text>
        <Text style={styles.headerSub}>{contacts.length} chargé{contacts.length !== 1 ? "s" : ""}</Text>
      </View>

      <View style={styles.searchBar}>
        <Ionicons name="search-outline" size={18} color={C.muted} style={{ marginRight: 8 }} />
        <TextInput
          style={styles.searchInput}
          placeholder="Rechercher par nom, email…"
          value={search}
          onChangeText={handleSearch}
          clearButtonMode="while-editing"
        />
      </View>

      {loading && contacts.length === 0 ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={C.primary} />
        </View>
      ) : error ? (
        <View style={styles.center}>
          <Ionicons name="cloud-offline-outline" size={48} color="#ccc" />
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryBtn} onPress={() => load()}>
            <Text style={styles.retryText}>Réessayer</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load({ refresh: true })} tintColor={C.primary} />}
          onEndReached={loadMore}
          onEndReachedThreshold={0.4}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="person-outline" size={48} color="#ccc" />
              <Text style={styles.emptyText}>{search ? "Aucun résultat" : "Aucun contact"}</Text>
            </View>
          }
          ListFooterComponent={loadingMore ? <ActivityIndicator color={C.primary} style={{ margin: 16 }} /> : null}
          renderItem={({ item }) => (
            <ContactItem item={item} onPress={(c) => navigation.navigate("ContactDetail", { id: c.id, email: c.email })} />
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { backgroundColor: C.primary, paddingTop: 50, paddingBottom: 16, paddingHorizontal: 20 },
  headerTitle: { color: "#fff", fontSize: 22, fontWeight: "bold" },
  headerSub: { color: "rgba(255,255,255,0.7)", fontSize: 13 },
  searchBar: {
    flexDirection: "row", alignItems: "center", backgroundColor: "#fff",
    margin: 12, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8, elevation: 1,
  },
  searchInput: { flex: 1, fontSize: 15, color: C.text },
  list: { padding: 12, paddingTop: 4 },
  card: {
    backgroundColor: "#fff", borderRadius: 12, padding: 14, marginBottom: 8,
    flexDirection: "row", alignItems: "center",
    elevation: 1, shadowColor: "#000", shadowOpacity: 0.04, shadowRadius: 3, shadowOffset: { height: 1 },
  },
  avatar: {
    width: 44, height: 44, borderRadius: 22,
    justifyContent: "center", alignItems: "center", marginRight: 12,
  },
  avatarText: { fontSize: 16, fontWeight: "bold", color: C.primary },
  info: { flex: 1 },
  name: { fontSize: 14, fontWeight: "600", color: C.text, marginBottom: 2 },
  email: { fontSize: 13, color: C.muted },
  statusRow: { flexDirection: "row", alignItems: "center", marginTop: 4, gap: 4 },
  dot: { width: 6, height: 6, borderRadius: 3 },
  statusText: { fontSize: 11, fontWeight: "600" },
  source: { fontSize: 11, color: "#aaa" },
  center: { flex: 1, justifyContent: "center", alignItems: "center", padding: 24 },
  empty: { alignItems: "center", marginTop: 60 },
  emptyText: { color: C.muted, marginTop: 12, fontSize: 15 },
  errorText: { color: C.muted, marginTop: 12, textAlign: "center" },
  retryBtn: { marginTop: 16, backgroundColor: C.primary, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 8 },
  retryText: { color: "#fff", fontWeight: "bold" },
});
