import React, { useState, useEffect, useLayoutEffect } from "react";
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  ActivityIndicator, Alert, RefreshControl,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { getCampaign, pauseCampaign, resumeCampaign, cancelCampaign } from "../api/client";

const C = { primary: "#1E3A5F", accent: "#E8B84B", bg: "#F5F7FA", text: "#222", muted: "#666" };

const STATUS_CONFIG = {
  draft:      { label: "Brouillon",   color: "#888" },
  scheduled:  { label: "Planifiée",   color: "#1976D2" },
  sending:    { label: "En cours",    color: "#388E3C" },
  sent:       { label: "Envoyée",     color: "#2E7D32" },
  paused:     { label: "En pause",    color: "#F57C00" },
  cancelled:  { label: "Annulée",     color: "#D32F2F" },
  failed:     { label: "Échec",       color: "#B71C1C" },
};

const pct = (n) => (n == null ? "—" : `${Number(n).toFixed(1)} %`);
const fmt = (n) => (n == null ? "—" : Number(n).toLocaleString("fr-FR"));

function MetricRow({ icon, label, value, color }) {
  return (
    <View style={styles.metricRow}>
      <View style={[styles.metricIcon, { backgroundColor: (color || C.primary) + "15" }]}>
        <Ionicons name={icon} size={18} color={color || C.primary} />
      </View>
      <Text style={styles.metricLabel}>{label}</Text>
      <Text style={[styles.metricValue, color && { color }]}>{value}</Text>
    </View>
  );
}

export default function CampaignDetailScreen({ route, navigation }) {
  const { id, name } = route.params;
  const [campaign, setCampaign] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState(null);

  useLayoutEffect(() => {
    navigation.setOptions({ title: name || "Campagne" });
  }, [name]);

  const load = async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true); else setLoading(true);
    setError(null);
    try {
      const res = await getCampaign(id);
      setCampaign(res.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { load(); }, [id]);

  const handleAction = (action, label) => {
    Alert.alert(
      `${label} cette campagne ?`,
      "Cette action sera appliquée immédiatement.",
      [
        { text: "Annuler", style: "cancel" },
        {
          text: label,
          style: action === "cancel" ? "destructive" : "default",
          onPress: async () => {
            setActionLoading(true);
            try {
              const fn = { pause: pauseCampaign, resume: resumeCampaign, cancel: cancelCampaign }[action];
              await fn(id);
              await load(true);
            } catch (err) {
              Alert.alert("Erreur", err.message);
            } finally {
              setActionLoading(false);
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return <View style={styles.center}><ActivityIndicator size="large" color={C.primary} /></View>;
  }
  if (error) {
    return (
      <View style={styles.center}>
        <Ionicons name="cloud-offline-outline" size={48} color="#ccc" />
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity style={styles.retryBtn} onPress={() => load()}>
          <Text style={styles.retryText}>Réessayer</Text>
        </TouchableOpacity>
      </View>
    );
  }
  if (!campaign) return null;

  const status = campaign.status;
  const cfg = STATUS_CONFIG[status] || { label: status, color: C.muted };
  const stats = campaign.stats;

  const canPause  = status === "sending";
  const canResume = status === "paused";
  const canCancel = ["sending", "paused", "scheduled"].includes(status);

  const fmtDate = (d) => d ? new Date(d).toLocaleString("fr-FR", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "—";

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.scroll}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load(true)} tintColor={C.primary} />}
    >
      {/* En-tête */}
      <View style={styles.card}>
        <View style={[styles.statusBadge, { backgroundColor: cfg.color + "20" }]}>
          <Text style={[styles.statusText, { color: cfg.color }]}>{cfg.label}</Text>
        </View>
        <Text style={styles.campName}>{campaign.name}</Text>

        <View style={styles.infoGrid}>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Créée le</Text>
            <Text style={styles.infoVal}>{fmtDate(campaign.created_at)}</Text>
          </View>
          {campaign.scheduled_at && (
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>Planifiée le</Text>
              <Text style={styles.infoVal}>{fmtDate(campaign.scheduled_at)}</Text>
            </View>
          )}
          {campaign.started_at && (
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>Démarrée le</Text>
              <Text style={styles.infoVal}>{fmtDate(campaign.started_at)}</Text>
            </View>
          )}
          {campaign.finished_at && (
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>Terminée le</Text>
              <Text style={styles.infoVal}>{fmtDate(campaign.finished_at)}</Text>
            </View>
          )}
        </View>
      </View>

      {/* Statistiques */}
      {stats ? (
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Statistiques</Text>

          <MetricRow icon="paper-plane" label="Envoyés" value={fmt(stats.counts?.sent)} />
          <MetricRow icon="checkmark-done" label="Délivrés" value={pct(stats.rates?.delivery)} color="#388E3C" />
          <MetricRow icon="eye-outline" label="Taux d'ouverture" value={pct(stats.rates?.open)} color="#1976D2" />
          <MetricRow icon="mouse-outline" label="Taux de clic" value={pct(stats.rates?.click)} color="#7B1FA2" />
          <MetricRow icon="return-down-back" label="Taux de bounce" value={pct(stats.rates?.bounce)} color="#F57C00" />
          <MetricRow icon="flag-outline" label="Plaintes" value={pct(stats.rates?.complaint)} color="#D32F2F" />
          <MetricRow icon="exit-outline" label="Désabonnements" value={pct(stats.rates?.unsubscribe)} color="#D32F2F" />

          {stats.counts && (
            <>
              <View style={styles.divider} />
              <Text style={styles.subTitle}>Volumes</Text>
              <MetricRow icon="close-circle-outline" label="Bounces" value={fmt(stats.counts.bounced)} color="#F57C00" />
              <MetricRow icon="person-remove-outline" label="Désabonnés" value={fmt(stats.counts.unsubscribed)} />
              <MetricRow icon="hand-left-outline" label="Plaintes" value={fmt(stats.counts.complained)} color="#D32F2F" />
            </>
          )}
        </View>
      ) : (
        status !== "draft" && (
          <View style={[styles.card, styles.noStats]}>
            <Ionicons name="stats-chart-outline" size={32} color="#ccc" />
            <Text style={styles.noStatsText}>Statistiques non disponibles pour le moment</Text>
          </View>
        )
      )}

      {/* Actions */}
      {(canPause || canResume || canCancel) && (
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Actions</Text>
          {actionLoading && <ActivityIndicator color={C.primary} style={{ marginBottom: 12 }} />}

          {canPause && (
            <TouchableOpacity style={[styles.actionBtn, { borderColor: "#F57C00" }]} onPress={() => handleAction("pause", "Mettre en pause")}>
              <Ionicons name="pause-circle-outline" size={20} color="#F57C00" />
              <Text style={[styles.actionText, { color: "#F57C00" }]}>Mettre en pause</Text>
            </TouchableOpacity>
          )}
          {canResume && (
            <TouchableOpacity style={[styles.actionBtn, { borderColor: "#388E3C" }]} onPress={() => handleAction("resume", "Reprendre")}>
              <Ionicons name="play-circle-outline" size={20} color="#388E3C" />
              <Text style={[styles.actionText, { color: "#388E3C" }]}>Reprendre l'envoi</Text>
            </TouchableOpacity>
          )}
          {canCancel && (
            <TouchableOpacity style={[styles.actionBtn, { borderColor: "#D32F2F" }]} onPress={() => handleAction("cancel", "Annuler")}>
              <Ionicons name="close-circle-outline" size={20} color="#D32F2F" />
              <Text style={[styles.actionText, { color: "#D32F2F" }]}>Annuler la campagne</Text>
            </TouchableOpacity>
          )}
        </View>
      )}

      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  scroll: { padding: 16 },
  center: { flex: 1, justifyContent: "center", alignItems: "center", padding: 24 },
  card: {
    backgroundColor: "#fff", borderRadius: 14, padding: 16, marginBottom: 12,
    elevation: 2, shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 4, shadowOffset: { height: 2 },
  },
  statusBadge: { alignSelf: "flex-start", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12, marginBottom: 10 },
  statusText: { fontSize: 12, fontWeight: "700" },
  campName: { fontSize: 20, fontWeight: "bold", color: C.text, marginBottom: 14 },
  infoGrid: { gap: 8 },
  infoItem: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  infoLabel: { fontSize: 13, color: C.muted },
  infoVal: { fontSize: 13, color: C.text, fontWeight: "500" },
  sectionTitle: { fontSize: 15, fontWeight: "bold", color: C.primary, marginBottom: 14 },
  subTitle: { fontSize: 13, fontWeight: "600", color: C.muted, marginTop: 4, marginBottom: 8 },
  divider: { height: 1, backgroundColor: "#f0f0f0", marginVertical: 12 },
  metricRow: { flexDirection: "row", alignItems: "center", paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: "#f5f5f5" },
  metricIcon: { width: 32, height: 32, borderRadius: 16, justifyContent: "center", alignItems: "center", marginRight: 12 },
  metricLabel: { flex: 1, fontSize: 14, color: C.text },
  metricValue: { fontSize: 15, fontWeight: "700", color: C.text },
  noStats: { alignItems: "center", padding: 24 },
  noStatsText: { color: C.muted, marginTop: 10, fontSize: 13 },
  actionBtn: {
    flexDirection: "row", alignItems: "center", gap: 10,
    borderWidth: 1.5, borderRadius: 10, padding: 14, marginBottom: 10,
  },
  actionText: { fontSize: 15, fontWeight: "600" },
  errorText: { color: C.muted, marginTop: 12, textAlign: "center" },
  retryBtn: { marginTop: 16, backgroundColor: C.primary, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 8 },
  retryText: { color: "#fff", fontWeight: "bold" },
});
