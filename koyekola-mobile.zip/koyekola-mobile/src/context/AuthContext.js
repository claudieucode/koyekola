import React, { createContext, useContext, useState, useEffect } from "react";
import { login as apiLogin, getMe, saveToken, getToken, removeToken } from "../api/client";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // vérification initiale du token

  // Au démarrage : vérifie si un token est stocké et toujours valide
  useEffect(() => {
    (async () => {
      try {
        const token = await getToken();
        if (token) {
          const { data } = await getMe();
          if (data?.user) setUser(data.user);
          else await removeToken();
        }
      } catch {
        await removeToken();
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const login = async (email, password) => {
    const { data } = await apiLogin(email, password);
    await saveToken(data.token);
    setUser(data.user);
    return data.user;
  };

  const logout = async () => {
    await removeToken();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
