// ⚠️  Remplace cette URL par l'adresse publique de ton serveur koyekola
// Exemple en local (même réseau Wi-Fi) : http://192.168.1.XX:3002
// Exemple en production                : https://koyekola.com
export const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || "https://koyekola.com";
