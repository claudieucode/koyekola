import AsyncStorage from "@react-native-async-storage/async-storage";
import { API_BASE_URL } from "../config";

const TOKEN_KEY = "mk_token";

// ─── stockage du token ──────────────────────────────────────────────────────
export const saveToken = (token) => AsyncStorage.setItem(TOKEN_KEY, token);
export const getToken = () => AsyncStorage.getItem(TOKEN_KEY);
export const removeToken = () => AsyncStorage.removeItem(TOKEN_KEY);

// ─── requête générique ──────────────────────────────────────────────────────
async function request(path, options = {}) {
  const token = await getToken();
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers,
  });

  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = json?.error?.message || `Erreur ${res.status}`;
    const err = new Error(msg);
    err.code = json?.error?.code;
    err.status = res.status;
    throw err;
  }
  return json;
}

// ─── Auth mobile ────────────────────────────────────────────────────────────
export const login = (email, password) =>
  request("/api/mobile/login", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  });

export const getMe = () => request("/api/mobile/me");

// ─── Vue d'ensemble ─────────────────────────────────────────────────────────
export const getOverview = () => request("/api/v1/overview");

// ─── Campagnes ──────────────────────────────────────────────────────────────
export const getCampaigns = (params = {}) => {
  const qs = new URLSearchParams();
  if (params.status) qs.set("status", params.status);
  if (params.q) qs.set("q", params.q);
  if (params.page) qs.set("page", String(params.page));
  return request(`/api/v1/campaigns?${qs}`);
};

export const getCampaign = (id) => request(`/api/v1/campaigns/${id}`);

export const pauseCampaign = (id) =>
  request(`/api/v1/campaigns/${id}/pause`, { method: "POST" });

export const resumeCampaign = (id) =>
  request(`/api/v1/campaigns/${id}/resume`, { method: "POST" });

export const cancelCampaign = (id) =>
  request(`/api/v1/campaigns/${id}/cancel`, { method: "POST" });

// ─── Contacts ───────────────────────────────────────────────────────────────
export const getContacts = (params = {}) => {
  const qs = new URLSearchParams();
  if (params.after) qs.set("after", String(params.after));
  if (params.limit) qs.set("limit", String(params.limit));
  return request(`/api/v1/contacts?${qs}`);
};

export const getContact = (id) => request(`/api/v1/contacts/${id}`);

// ─── Listes ─────────────────────────────────────────────────────────────────
export const getLists = () => request("/api/v1/lists");
