# Koyekola Mobile — Guide d'installation

## 1. Déployer les fichiers backend dans koyekola

### 1a. Copier les fichiers API

Copie les deux fichiers suivants dans ton projet koyekola :

```
koyekola-mobile-backend/router.js       →  src/marketing/api/router.js     (REMPLACE l'existant)
koyekola-mobile-backend/mobile-auth.js  →  src/marketing/api/mobile-auth.js (NOUVEAU fichier)
```

### 1b. Modifier server.js

Ouvre `server.js` et ajoute ces lignes **avant** le bloc `app.use(session(...))` :

```js
// ── API Mobile (auth email→token) ───────────────────────────────────────────
const { createMobileAuthRouter } = require("./src/marketing/api/mobile-auth");
app.use("/api/mobile", createMobileAuthRouter({ db }));
```

Exemple (cherche `app.use(session(` dans server.js) :

```js
// AVANT session — pas de vérification CSRF ici
const { createMobileAuthRouter } = require("./src/marketing/api/mobile-auth");
app.use("/api/mobile", createMobileAuthRouter({ db }));

app.use(session({   // ← cette ligne existait déjà
  ...
```

### 1c. Redémarre le serveur

```bash
npm start
# ou si tu utilises PM2 :
pm2 restart koyekola
```

### 1d. Vérifie que l'API fonctionne

```bash
# Test login (remplace les valeurs)
curl -X POST https://ton-domaine.com/api/mobile/login \
  -H "Content-Type: application/json" \
  -d '{"email":"formateur@example.com","password":"ton_mot_de_passe"}'

# Réponse attendue :
# { "data": { "token": "mk_live_...", "user": { ... } } }
```

---

## 2. Configurer l'app mobile

### 2a. Éditer l'URL du serveur

Ouvre `src/config.js` et remplace l'URL :

```js
export const API_BASE_URL = "https://ton-domaine.com";
```

Si tu veux tester en local (même réseau Wi-Fi) :
```js
export const API_BASE_URL = "http://192.168.1.XX:3002";  // IP de ton Mac
```

### 2b. Installer les dépendances

```bash
cd koyekola-mobile
npm install
```

---

## 3. Tester avec Expo Go (rapide, sans build)

```bash
npm start
# Scanne le QR code avec l'app Expo Go (Android)
```

> ⚠️ Expo Go nécessite que ton téléphone et ton Mac soient sur le **même réseau Wi-Fi**.

---

## 4. Construire le vrai APK (à installer directement)

### Prérequis
- Compte sur https://expo.dev (gratuit)
- EAS CLI : `npm install -g eas-cli`

### Étapes

```bash
# 1. Connexion à Expo
eas login

# 2. Initialisation du projet (une seule fois)
eas init --id koyekola-mobile

# 3. Build APK (profile "preview")
eas build --platform android --profile preview
```

EAS Build compile dans le cloud (pas besoin d'Android Studio).
Télécharge l'APK depuis le lien affiché ou depuis https://expo.dev/accounts/[ton-compte]/builds.

### Installer l'APK sur Android

1. Transfère le fichier `.apk` sur le téléphone (USB, WhatsApp, Drive…)
2. Dans les **Paramètres Android > Sécurité**, active **"Sources inconnues"** (ou "Installer des applis inconnues")
3. Ouvre le fichier `.apk` et installe

---

## 5. Structure de l'app

```
koyekola-mobile/
├── App.js                          — point d'entrée
├── app.json                        — config Expo
├── eas.json                        — config EAS Build
├── src/
│   ├── config.js                   — URL du serveur (à modifier)
│   ├── api/
│   │   └── client.js               — toutes les fonctions API
│   ├── context/
│   │   └── AuthContext.js          — login/logout, stockage du token
│   ├── navigation/
│   │   └── AppNavigator.js         — navigation (tabs + stack)
│   └── screens/
│       ├── LoginScreen.js          — connexion formateur
│       ├── DashboardScreen.js      — tableau de bord (stats)
│       ├── CampaignsScreen.js      — liste des campagnes
│       ├── CampaignDetailScreen.js — détail + pause/reprise/annulation
│       ├── ContactsScreen.js       — liste des contacts
│       └── ContactDetailScreen.js  — fiche contact
```

---

## 6. Fonctionnalités de l'app

| Écran | Fonctions |
|---|---|
| Login | Email + mot de passe (compte formateur koyekola) |
| Tableau de bord | Contacts totaux/actifs/nouveaux, campagnes envoyées, taux de clic/bounce, automatisations |
| Campagnes | Liste paginée, filtre par statut, recherche, pull-to-refresh |
| Détail campagne | Stats complètes (ouvertures, clics, bounces…), actions pause/reprise/annulation |
| Contacts | Liste paginée (50/page), recherche locale par nom/email |
| Détail contact | Fiche complète, statut, source, date d'inscription |

---

## 7. Sécurité

- Le token `mk_live_...` est stocké de manière sécurisée dans **AsyncStorage** sur l'appareil
- Chaque connexion **révoque** l'ancien token "App Mobile" et en génère un nouveau
- Le token est transmis en en-tête `Authorization: Bearer ...` (HTTPS uniquement en production)
- Seuls les utilisateurs de rôle **formateur** peuvent se connecter
